<?php
/*
Plugin Name: Ops Mage API
Description: Sends a requests to Ops Mage API and populates to global mage variable
Version: 1.0
Author: Leif Orion Kramer - Ops Mage, Inc. www.opsmage.io
*/

// Security check to ensure WordPress is running
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include necessary files
require_once plugin_dir_path(__FILE__) . 'includes/api-request-handler.php';
require_once plugin_dir_path(__FILE__) . 'includes/settings-page.php';

// Hook into the page load
add_action('wp', 'send_api_request_on_page_load');
