<?php

function ops_mage_api_add_admin_menu() {
    add_options_page(
        'Ops Mage API Settings',  // Page title
        'Ops Mage API',           // Menu title
        'manage_options',         // Capability
        'ops-mage-api',           // Menu slug
        'ops_mage_api_settings_page' // Function to display the settings page
    );
}
add_action('admin_menu', 'ops_mage_api_add_admin_menu');

function ops_mage_api_settings_page() {
    ?>
    <div class="wrap">
        <h1>Ops Mage API Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ops_mage_api_settings');
            do_settings_sections('ops-mage-api');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function ops_mage_api_settings_init() {
    register_setting('ops_mage_api_settings', 'custom_api_key');

    add_settings_section(
        'ops_mage_api_section',
        __('API Configuration', 'ops-mage-api'),
        null,
        'ops-mage-api'
    );

    add_settings_field(
        'custom_api_key',
        __('API Key', 'ops-mage-api'),
        'custom_api_key_render',
        'ops-mage-api',
        'ops_mage_api_section'
    );
}
add_action('admin_init', 'ops_mage_api_settings_init');

function custom_api_key_render() {
    $custom_api_key = get_option('custom_api_key');
    ?>
    <input type="text" name="custom_api_key" value="<?php echo esc_attr($custom_api_key); ?>" size="40">
    <?php
}
