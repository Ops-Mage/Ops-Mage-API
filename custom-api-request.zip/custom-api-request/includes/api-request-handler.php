<?php

function encode_base64($input_string) {
    // Convert the input string to UTF-8 bytes
    $utf8_string = mb_convert_encoding($input_string, 'UTF-8', 'auto');
    
    // Perform the base64 encoding
    $base64_string = base64_encode($utf8_string);
    
    // Ensure the Base64 string length is a multiple of 4 by adding necessary padding
    $padding_needed = strlen($base64_string) % 4;
    if ($padding_needed > 0) {
        $base64_string .= str_repeat('=', 4 - $padding_needed);
    }

    return $base64_string;
}

function send_api_request_on_page_load() {
    // Ensure the function only fires on singular posts or pages
    if (!is_singular()) {
        return;  // Exit if not on a singular post or page
    }

    static $script_added = false;  // Static variable to track if the script has been added

    if ($script_added) {
        return;  // Exit if the script has already been added
    }

    $api_key = get_option('custom_api_key');
    $url = "https://opsmage-api.io/context/api";

    $page_url = get_permalink();
    $page_content = get_the_content();

    // Strip all HTML tags from the content
    $clean_content = wp_strip_all_tags($page_content);

    $content_id = encode_base64($page_url);

    $params = array(
        'api_key' => $api_key,
        'content_id' => $content_id
    );
    //'timestamp' => time()

    // Perform the GET request
    $get_response = wp_remote_get(add_query_arg($params, $url));

    // Define the default JSON object for errors
    $default_json_response = array(
        "content_classification" => array(
            "ops_mage_data_id" => "",
            "content_id" => "",
            "media_type" => "",
            "publisher_domain" => "",
            "client_account_id" => "",
            "res_score" => 0,
            "res_score_bucket" => "unscored",
            "iab_cats" => array(),
            "iab_cat_ids" => array(),
            "brands" => array(),
            "brand_ids" => array(),
            "restricted_cats" => array(),
            "restricted_cat_ids" => array(),
            "sentiment" => array(),
            "sentiment_ids" => array(),
            "content_status" => "Error"
        )
    );

    if (is_wp_error($get_response)) {
        error_log('GET Request Error: ' . $get_response->get_error_message());
        $json_response = $default_json_response;  // Use the default JSON object on error
    } else {
        $get_body = wp_remote_retrieve_body($get_response);
        $get_json_response = json_decode($get_body, true);

        // Check for the presence of "error" in the response
        if (isset($get_json_response['error']) || 
            isset($get_json_response['content_classification']['ops_mage_data_id']) && 
            $get_json_response['content_classification']['ops_mage_data_id'] === 'No Item Found') {

            // If there's an error or "No Item Found", make the POST request
            $data = array(
                'content' => $clean_content,  // Use the cleaned content
                'image_id' => '',
                'image_path' => '',
                'domain' => $_SERVER['HTTP_HOST']
            );

            $headers = array(
                'Content-Type' => 'application/json'
            );

            error_log('POST Request URL: ' . add_query_arg($params, $url));
            error_log('POST Request Headers: ' . print_r($headers, true));
            error_log('POST Request Body: ' . json_encode($data));

            $post_response = wp_remote_post(add_query_arg($params, $url), array(
                'body'    => json_encode($data),
                'headers' => $headers
            ));

            if (is_wp_error($post_response)) {
                error_log('POST Request Error: ' . $post_response->get_error_message());
                $json_response = $default_json_response;  // Use the default JSON object on error
            } else {
                $post_body = wp_remote_retrieve_body($post_response);
                $json_response = json_decode($post_body, true);
                
                // Check if the POST response has an error
                if (isset($json_response['error'])) {
                    $json_response = $default_json_response;  // Use the default JSON object on error
                }
                
                error_log('POST Response Body: ' . $post_body);
            }
        } else {
            // Use the GET response JSON if it's not "No Item Found" and no error is present
            $json_response = $get_json_response['content_classification'];
            error_log('GET Response Body used: ' . $get_body);
        }
    }

    // Prepend the script to wp_head with priority 0
    add_action('wp_head', function() use ($json_response) {
        echo '<script type="text/javascript">';
        echo 'var defaultResponse = {
                "content_classification": {
                "ops_mage_data_id": "",
                "content_id": "",
                "media_type": "",
                "publisher_domain": "",
                "res_score": 0,
                "res_score_bucket": "unscored",
                "iab_cats": [],
                "iab_cat_ids": [],
                "brands": [],
                "brand_ids": [],
                "restricted_cats": [],
                "restricted_cat_ids": [],
                "sentiment": [],
                "sentiment_ids": []
            }
        };';
        echo 'var mage = ' . json_encode($json_response) . ';';
        echo 'try {
            var mage = mage || defaultResponse
                }
            catch (error) {
                var mage = defaultResponse}';
        echo '</script>';
    }, 0);

    $script_added = true;  // Mark the script as added
}

// Hook the function to template_redirect to ensure it only fires on singular posts or pages
add_action('template_redirect', 'send_api_request_on_page_load');